/*!
 * LiquidGlass — React wrapper.
 *
 * Thin by design: the engine owns the canvas and its own rAF loop, so this
 * component's only jobs are creating it once, forwarding prop changes through
 * set(), and tearing down on unmount.
 *
 *   import LiquidGlass from './liquid-glass-react';
 *
 *   <LiquidGlass
 *     style={{ width: '100%', height: 420 }}
 *     background={{ type: 'image', src: '/bg.jpg' }}
 *     refraction={{ thickness: 26, ior: 1.5, dispersion: 12 }}
 *     shapes={[{ x: '50%', y: '50%', width: 300, height: 220 }]}
 *   />
 *
 * Requires liquid-glass.js to be loadable as a module or present on window.
 */
import React, { useRef, useEffect, useImperativeHandle, forwardRef } from 'react';
// liquid-glass.js is UMD: it sets module.exports to the API object directly.
// Bundler interop may surface that as the default export or as the namespace,
// so accept either, and fall back to the global for plain <script> setups.
import * as CoreNS from './liquid-glass.js';

const Engine =
  (CoreNS && typeof CoreNS.create === 'function' && CoreNS) ||
  (CoreNS && CoreNS.default && typeof CoreNS.default.create === 'function' && CoreNS.default) ||
  (typeof window !== 'undefined' ? window.LiquidGlass : null);

// Config keys the engine understands. Anything else on props is treated as a
// DOM attribute and spread onto the canvas.
const CONFIG_KEYS = [
  'background', 'shapes', 'mergeRate', 'refraction', 'fresnel', 'glare',
  'blur', 'tint', 'shadow', 'spring', 'followPointer', 'reducedMotion'
];

function splitProps(props) {
  const config = {};
  const rest = {};
  for (const key of Object.keys(props)) {
    if (key === 'children' || key === 'onReady') continue;
    if (CONFIG_KEYS.includes(key)) config[key] = props[key];
    else rest[key] = props[key];
  }
  return { config, rest };
}

const LiquidGlass = forwardRef(function LiquidGlass(props, ref) {
  const canvasRef = useRef(null);
  const glassRef = useRef(null);
  const { config, rest } = splitProps(props);

  // Create once. Deliberately not keyed on config — prop changes go through
  // set() below, since recreating the context per render would be ruinous.
  useEffect(() => {
    if (!Engine) {
      console.error('[LiquidGlass] engine not found — check the import path.');
      return;
    }
    const glass = Engine.create(canvasRef.current, config);
    glassRef.current = glass;
    if (props.onReady) props.onReady(glass);
    return () => { glass.destroy(); glassRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Forward config changes. Serialising for the comparison keeps this cheap and
  // avoids re-firing when a parent passes fresh object literals each render —
  // the common case that would otherwise thrash set() every frame.
  const serialised = JSON.stringify(config);
  useEffect(() => {
    if (glassRef.current) glassRef.current.set(JSON.parse(serialised));
  }, [serialised]);

  useImperativeHandle(ref, () => ({
    /** The underlying engine instance. */
    get instance() { return glassRef.current; },
    set: (patch) => glassRef.current && glassRef.current.set(patch),
    render: () => glassRef.current && glassRef.current.render(),
    invalidate: () => glassRef.current && glassRef.current.invalidate(),
    fps: () => (glassRef.current ? glassRef.current.fps() : 0)
  }), []);

  return <canvas ref={canvasRef} {...rest} />;
});

export default LiquidGlass;
