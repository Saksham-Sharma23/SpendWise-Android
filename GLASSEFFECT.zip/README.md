# LiquidGlass

Apple-style liquid glass for the web. Real optics — per-pixel Snell's law
refraction through a superellipse bevel, chromatic dispersion, two-lobe specular
glare, and highlight compositing in LCH colour space.

WebGL2. Zero dependencies. One file.

```js
const glass = LiquidGlass.create(document.querySelector('canvas'), {
  background: { type: 'image', src: 'bg.jpg' },
  shapes: [{ x: '50%', y: '50%', width: 300, height: 220 }],
  refraction: { thickness: 26, ior: 1.5, dispersion: 12 },
});
```

Open `index.html` for a studio with live controls for every parameter, five
presets, and a copy-config button.

---

## Quick start

```html
<canvas id="glass" style="width:100%;height:420px"></canvas>
<script src="liquid-glass.js"></script>
<script>
  LiquidGlass.create(document.getElementById('glass'), {
    background: { type: 'gradient' },
    shapes: [{ x: '50%', y: '50%', width: 320, height: 200, radius: 90 }],
  });
</script>
```

React:

```jsx
import LiquidGlass from './liquid-glass-react';

<LiquidGlass
  style={{ width: '100%', height: 420 }}
  background={{ type: 'image', src: '/bg.jpg' }}
  refraction={{ thickness: 26, ior: 1.5, dispersion: 12 }}
/>
```

---

## Read this before you start: what the glass sits on

**The glass refracts a texture that the shader owns, not the web page behind
it.** This is the single most important thing to understand, and it is a
consequence of how refraction works: bending light means sampling *arbitrary*
pixels from the backdrop, including pixels outside the element's own bounds.
The browser gives no API for that against live DOM.

So you supply the backdrop as a source:

| `background.type` | Use for | Cost |
|---|---|---|
| `gradient` | Animated procedural blobs. No assets needed. | Free |
| `stripes` / `checker` | Debugging — refraction is *invisible* over flat colour | Free |
| `image` | Photo/artwork backdrops | One upload |
| `video` | Live video backdrops | Re-upload per frame |
| `canvas` | Anything you draw yourself | On `markChanged()` |
| `dom` | Real HTML content (see caveats) | Expensive |

If you want glass over your actual page content, put your content *in* the
background (as an image, a canvas you draw, or via `dom` capture) and layer real
interactive HTML on top of the canvas. That is how the reference
implementations do it too.

### The `dom` source and its caveats

`{ type: 'dom', element: node }` rasterises a DOM subtree through
SVG `<foreignObject>` into a texture. It works, and it needs no dependency, but:

- **Content under the glass is a snapshot.** Live text, carets, videos and CSS
  animations are frozen until you call `glass.source.markChanged()`.
- External images need CORS headers; web fonts must be embedded as data URIs or
  they rasterise with a fallback face.
- Cross-origin iframes and `<canvas>` subtrees will not rasterise.
- Capture cost scales with DOM complexity. It is not a per-frame operation.

Every library that claims "liquid glass over live HTML" has these same limits,
whether it uses `foreignObject` or `html2canvas`. Prefer a texture source
whenever you control the backdrop.

---

## Parameters

All values are live-patchable via `glass.set({ ... })`.

### `refraction`
| Key | Default | Range | Meaning |
|---|---|---|---|
| `thickness` | `20` | 1–90 px | Width of the bevel band, measured inward from the rim. The main "how thick is this glass" dial. |
| `ior` | `1.4` | 1–3 | Refractive index. `1.0` = no bending (clean pass-through), `1.5` ≈ crown glass, `2.4` ≈ diamond. |
| `dispersion` | `7` | 0–50 | Chromatic aberration. Spreads R/G/B refraction, giving prismatic fringing at the rim. `0` = off. |

### `shapes[]`
| Key | Default | Meaning |
|---|---|---|
| `x`, `y` | `'50%'` | Centre. Number = px, string = percent of canvas. |
| `width`, `height` | `240` | Size in CSS px. |
| `radius` | `80` | Corner radius as % of `min(w,h)/2`. |
| `roundness` | `5` | Superellipse exponent. `2` = circular corners, `~5` = Apple squircle, `7` = boxy. |
| `followPointer` | — | Shape tracks the pointer with spring physics. |

Up to 8 shapes. They blob-merge via smooth-min — see `mergeRate` (default
`0.05`, range 0–0.3).

### `blur`
| Key | Default | Meaning |
|---|---|---|
| `radius` | `8` | Blur radius in px. |
| `edge` | `false` | `false` = only the curved bevel diffuses, flat centre stays optically clear (real thick glass). `true` = frost the whole pane (translucent panel). |
| `quality` | `'half'` | `'full'` / `'half'` / `'quarter'` — resolution the blur runs at. `half` is visually indistinguishable and much cheaper. |

### `glare` and `fresnel`
| Key | Default | Meaning |
|---|---|---|
| `glare.angle` | `-45` | Light direction in degrees. |
| `glare.factor` | `90` | Strength (0–120). |
| `glare.range` | `30` | How far in from the rim the highlight reaches. |
| `glare.hardness` | `20` | Falloff sharpness. |
| `glare.convergence` | `50` | Higher = tighter, more concentrated highlight. |
| `glare.oppositeFactor` | `80` | Brightness of the second (far-rim) lobe. |
| `fresnel.factor` | `20` | Rim brightness from grazing-angle reflection. |
| `fresnel.range` / `.hardness` | `30` / `20` | Falloff shape. |

### `tint`, `shadow`, `spring`
| Key | Default | Meaning |
|---|---|---|
| `tint` | `{r:255,g:255,b:255,a:0}` | Body colour. `a` drives strength. |
| `shadow.factor` | `15` | Contact shadow opacity (0–100). |
| `shadow.expand` | `25` | Shadow spread. |
| `shadow.x` / `.y` | `0` / `8` | Offset in px. |
| `spring.stiffness` / `.damping` | `170` / `20` | Pointer-follow feel. |
| `spring.sizeFactor` | `10` | Velocity squash & stretch. `0` = rigid. |

---

## API

```js
const glass = LiquidGlass.create(canvas, options);

glass.set({ refraction: { ior: 1.6 } });  // live patch, no reallocation
glass.get();                              // current config (deep copy)
glass.invalidate();                       // request a redraw
glass.render();                           // draw immediately, outside the loop
glass.fps();                              // measured fps
glass.destroy();                          // release all GL objects + listeners

LiquidGlass.isSupported();                // WebGL2 available?
```

`glass.source.markChanged()` forces a re-capture on `canvas` and `dom` sources.

---

## Performance

Measured on an NVIDIA GT 1030 (a low-end 2017 card) at 1600×900 with two
merged shapes and the pointer moving: **locked 60fps at every blur quality**,
including `radius: 30` at full resolution.

The engine is built to do nothing when nothing changes:

- **Render-on-demand.** Redraws only when a uniform changes, a spring is still
  settling, or the source has a new frame. A static scene issues **1 draw call
  per 1.2 s**, versus 60 for an animated one. (Verified, not asserted.)
- **`IntersectionObserver`** stops all work when the canvas scrolls off-screen.
- **Downsampled blur** at ½ or ¼ resolution. The blurred texture is only ever
  read through a lens, so the detail is unobservable.
- **Linear-sampled Gaussian** — taps land between texel pairs so hardware
  bilinear filtering resolves two samples per fetch. `radius: 8` costs 5 taps,
  not 9; `radius: 30` costs 16, not 31.
- **One WebGL context** for any number of shapes. Several popular libraries
  create one context *per element*, which hits the browser's ~16-context cap
  and silently kills the oldest canvas.
- Uniform locations cached; float FBOs keep blur and LCH maths out of 8-bit
  quantisation.

Tuning for slower hardware: drop `blur.quality` to `'quarter'`, lower
`blur.radius`, reduce `refraction.dispersion` (it costs 3 extra texture fetches
when non-zero), and keep shape count low.

---

## Browser support

Needs **WebGL2** — Chrome/Edge 56+, Firefox 51+, Safari 15+. That is ~97% of
browsers, and unlike the CSS approach it behaves *identically* across all of
them.

Graceful degradation, both paths verified:

1. No `EXT_color_buffer_float` → `RGBA8` framebuffers. Slight banding in the
   glare gradient; everything else identical.
2. No WebGL2 at all → the canvas gets a CSS `backdrop-filter: blur()` frosted
   panel so layouts do not break.

Context loss (from too many live contexts, GPU reset, or tab backgrounding) is
detected and the context is actively restored, then all GL resources rebuilt.

### Why not CSS?

`backdrop-filter: url(#svg-filter)` with `feDisplacementMap` is the usual
CSS-only recipe, and it has two fatal problems:

- **It is Chromium-only.** [WebKit bug 245510](https://bugs.webkit.org/show_bug.cgi?id=245510)
  is open and Firefox has no implementation. Both parse the syntax as valid and
  then silently no-op the filter, so the effect degrades to plain blur without
  warning. Most published "liquid glass" snippets are broken in Safari and
  Firefox and do not say so.
- **`feDisplacementMap` cannot refract.** It only shifts existing backdrop
  pixels. It cannot magnify, cannot sample outside the element's bounds, and
  cannot mix sharp and blurred sources per colour channel — so no true lensing
  and no real dispersion.

---

## Files

| File | |
|---|---|
| `liquid-glass.js` | The engine. Zero dependencies, UMD. |
| `liquid-glass-react.jsx` | React wrapper. |
| `index.html` | Studio demo with live controls and presets. |

---

## Credits

Shader techniques derived from
[iyinchao/liquid-glass-studio](https://github.com/iyinchao/liquid-glass-studio),
notably the analytic-bevel Snell formulation, the deliberately unnormalised SDF
gradient (its magnitude is load-bearing as a highlight weight), and LCH
highlight compositing. Smooth-min and the rounded-box SDF are Inigo Quilez's.

MIT.
