# How the Nav Header Blur Works on my protfolio site

The floating pill nav in [components/Header.tsx](components/Header.tsx) looks like "liquid glass" because several layers are stacked. The blur on its own isn't what sells it. It works because of the blur, a saturation boost, a translucent tint, a thin light border, a top highlight and a soft shadow together.

## The values

All of this is on the pill `<div>` (Header.tsx, lines 44–49):

| Layer | Class / style | Actual value | What it does |
|---|---|---|---|
| Backdrop blur | `backdrop-blur-xl` | `blur(24px)` | Heavily blurs whatever is behind the nav (the starfield, section text) |
| Saturation boost | `backdrop-saturate-150` | `saturate(150%)` | Makes the blurred colors *more* vivid rather than washed-out grey |
| Safari fallback | `style={{ WebkitBackdropFilter: 'blur(20px) saturate(150%)' }}` | `blur(20px) saturate(150%)` | Prefixed version so Safari/iOS render the glass too |
| Tint (light) | `bg-white/40` | `rgba(255,255,255,0.4)` | Milky frosted layer |
| Tint (dark) | `dark:bg-white/5` | `rgba(255,255,255,0.05)` | Barely-there frost. Keeps the dark background dark |
| Border (light) | `border-white/40` | 1px `rgba(255,255,255,0.4)` | Bright rim, like the edge of a glass pane |
| Border (dark) | `dark:border-white/10` | 1px `rgba(255,255,255,0.1)` | Subtle rim that separates the pill from the page |
| Shadow | `shadow-[0_8px_32px_rgba(0,0,0,0.12)]` | `0 8px 32px rgba(0,0,0,.12)` | Big, soft, low-opacity shadow that lifts it off the page |
| Shadow (scrolled) | `shadow-[0_8px_32px_rgba(0,0,0,0.2)]` | opacity → `0.2` | Once `scrollY > 20`, the shadow deepens so the pill separates from the content scrolling under it |
| Shape | `rounded-full` + `overflow-hidden` | pill | Clips the highlight layer to the pill shape |
| Transition | `transition-all duration-300` | 300ms | Smooth shadow change on scroll |

### The sheen layer

Inside the pill there is an absolutely positioned `<span>` (line 49):

```html
<span class="pointer-events-none absolute inset-0 rounded-full
             bg-gradient-to-b from-white/50 to-transparent
             dark:from-white/10 opacity-60"></span>
```

- A vertical gradient from `white/50` (light) or `white/10` (dark) down to transparent, at `opacity-60`.
- The top edge ends up brighter than the bottom, the way light catches the top of a curved glass surface. This is the part that makes it read as "glass" rather than just "blurry box".
- `pointer-events-none` means it never blocks clicks on the links.

### Hover states

Each link and the theme toggle get `hover:bg-white/50` (light) or `dark:hover:bg-white/10` (dark), so hovering adds another frosted pill inside the glass.

## Why it looks good

1. **A strong blur radius (20–24px).** Anything below ~12px still shows recognizable shapes behind the nav and looks noisy. At 24px the background turns into smooth color fields.
2. **Saturation at 150%.** Blur on its own averages colors toward grey and looks muddy. Boosting saturation keeps the warm amber/coral tones from the page glowing through. This is the same trick Apple uses in macOS/iOS materials.
3. **A low-opacity tint.** At 40% in light mode and 5% in dark mode, the background stays visible. A heavier tint would turn it into a solid bar.
4. **A light-colored border, not a dark one.** A 1px translucent white rim imitates the refracting edge of glass and defines the shape without a hard outline.
5. **The top-down gradient highlight** gives it depth and curvature.
6. **A diffuse shadow** (32px blur, 8px offset, 12–20% opacity) makes it float, and it gets stronger on scroll so the pill stays legible over busy content.
7. **Something interesting behind it.** Backdrop blur only shows off when there is texture underneath: the starfield and the translucent section backgrounds.

## Note: 24px vs 20px

The class `backdrop-blur-xl` resolves to **24px** in Tailwind v3 (loaded via the CDN in `index.html`), but the inline `WebkitBackdropFilter` uses **20px**. Chromium/Firefox use the unprefixed property (24px) and Safari uses the prefixed inline style (20px), so the blur is slightly softer in Safari. To make them identical, change the inline style to `blur(24px) saturate(150%)`.

## Reusing it

A copy-paste recipe for the same effect in plain CSS:

```css
.glass-pill {
  border-radius: 9999px;
  border: 1px solid rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.4);
  -webkit-backdrop-filter: blur(24px) saturate(150%);
  backdrop-filter: blur(24px) saturate(150%);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
  position: relative;
  overflow: hidden;
}
.dark .glass-pill {
  border-color: rgba(255, 255, 255, 0.1);
  background: rgba(255, 255, 255, 0.05);
}
.glass-pill::before { /* sheen */
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: linear-gradient(to bottom, rgba(255, 255, 255, 0.5), transparent);
  opacity: 0.6;
  pointer-events: none;
}
.dark .glass-pill::before {
  background: linear-gradient(to bottom, rgba(255, 255, 255, 0.1), transparent);
}
```
