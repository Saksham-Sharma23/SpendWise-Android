/*!
 * LiquidGlass v2.0 — Apple-style liquid glass for the web, in WebGL2.
 *
 * Real optics, not a blur: per-pixel Snell's law refraction through a
 * superellipse bevel, 3-sample chromatic dispersion, two-lobe specular glare,
 * and highlight compositing in LCH colour space.
 *
 * Zero dependencies. Single file. MIT.
 *
 *   const glass = LiquidGlass.create(canvas, {
 *     background: { type: 'gradient' },
 *     shapes: [{ x: '50%', y: '50%', width: 260, height: 260 }],
 *   });
 *
 * Why WebGL and not CSS: `backdrop-filter: url(#svg-filter)` is Chromium-only
 * (WebKit bug 245510, no Firefox impl), and `feDisplacementMap` can only shove
 * existing backdrop pixels around — it cannot magnify, cannot sample outside
 * the element, and cannot mix sharp/blurred sources per colour channel. Real
 * lensing needs random access to a background texture.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else if (typeof define === 'function' && define.amd) define(factory);
  else root.LiquidGlass = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var MAX_SHAPES = 8;
  var MAX_BLUR_RADIUS = 128;

  // ═══════════════════════════════════════════════════════════════════════
  // Defaults. Tuned to match the reference implementation's values, except
  // blur.radius which defaults to something actually visible.
  // ═══════════════════════════════════════════════════════════════════════
  var DEFAULTS = {
    background: { type: 'gradient', src: null, fit: 'cover' },
    shapes: [{
      x: '50%', y: '50%',
      width: 240, height: 240,
      radius: 80,        // % of min(w,h)/2
      roundness: 5,      // superellipse exponent: 2 = circle, 5 = Apple squircle
      followPointer: false
    }],
    mergeRate: 0.05,     // smooth-min k, in normalised-height units
    refraction: {
      thickness: 20,     // px — bevel band width, measured inward from the rim
      ior: 1.4,          // refractive index
      dispersion: 7      // chromatic spread multiplier
    },
    fresnel: { range: 30, hardness: 20, factor: 20 },
    glare: {
      range: 30, hardness: 20, factor: 90,
      convergence: 50, oppositeFactor: 80, angle: -45
    },
    // radius: px. edge: true = frost the entire pane uniformly; false = only
    // the bevel band diffuses, leaving the flat centre optically clear, which
    // is how real thick glass behaves. quality: 'full' | 'half' | 'quarter'.
    blur: { radius: 8, edge: false, quality: 'half' },
    tint: { r: 255, g: 255, b: 255, a: 0 },
    shadow: { expand: 25, factor: 15, x: 0, y: 8 },
    spring: { stiffness: 170, damping: 20, sizeFactor: 10 },
    followPointer: true,
    reducedMotion: 'auto'
  };

  function deepMerge(base, patch) {
    var out = Array.isArray(base) ? base.slice() : Object.assign({}, base);
    if (!patch) return out;
    for (var k in patch) {
      if (!Object.prototype.hasOwnProperty.call(patch, k)) continue;
      var v = patch[k];
      if (v && typeof v === 'object' && !Array.isArray(v) &&
          out[k] && typeof out[k] === 'object' && !Array.isArray(out[k])) {
        out[k] = deepMerge(out[k], v);
      } else if (Array.isArray(v)) {
        out[k] = v.slice();
      } else {
        out[k] = v;
      }
    }
    return out;
  }

  // ═══════════════════════════════════════════════════════════════════════
  // GLSL — shared library
  // ═══════════════════════════════════════════════════════════════════════

  var VERT = `#version 300 es
in vec2 a_position;
out vec2 v_uv;
void main() {
  v_uv = (a_position + 1.0) * 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}`;

  // sRGB ↔ linear ↔ XYZ ↔ Lab ↔ LCH.
  // Compositing highlights in LCH rather than mixing toward white in RGB is
  // most of the perceived quality: it lets us push lightness past the display
  // range while keeping hue stable, so a specular hit reads as *bright glass*
  // rather than as a grey wash.
  var LIB_COLOR = `
const float PI = 3.14159265359;

float srgb_to_linear(float c) {
  return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4);
}
float linear_to_srgb(float c) {
  return c <= 0.0031308 ? c * 12.92 : 1.055 * pow(c, 1.0 / 2.4) - 0.055;
}
vec3 srgb_to_linear(vec3 c) {
  return vec3(srgb_to_linear(c.r), srgb_to_linear(c.g), srgb_to_linear(c.b));
}
vec3 linear_to_srgb(vec3 c) {
  return vec3(linear_to_srgb(c.r), linear_to_srgb(c.g), linear_to_srgb(c.b));
}

const mat3 RGB_TO_XYZ = mat3(
  0.4124564, 0.2126729, 0.0193339,
  0.3575761, 0.7151522, 0.1191920,
  0.1804375, 0.0721750, 0.9503041
);
const mat3 XYZ_TO_RGB = mat3(
   3.2404542, -0.9692660,  0.0556434,
  -1.5371385,  1.8760108, -0.2040259,
  -0.4985314,  0.0415560,  1.0572252
);
const vec3 D65 = vec3(0.95047, 1.0, 1.08883);

float lab_f(float t) {
  return t > 0.008856451679 ? pow(t, 1.0 / 3.0) : (903.2962962 * t + 16.0) / 116.0;
}
float lab_finv(float t) {
  return t > 0.2068965517 ? t * t * t : (116.0 * t - 16.0) / 903.2962962;
}

vec3 SRGB_TO_LCH(vec3 srgb) {
  vec3 xyz = RGB_TO_XYZ * srgb_to_linear(srgb) / D65;
  vec3 f = vec3(lab_f(xyz.x), lab_f(xyz.y), lab_f(xyz.z));
  float L = 116.0 * f.y - 16.0;
  float a = 500.0 * (f.x - f.y);
  float b = 200.0 * (f.y - f.z);
  float C = length(vec2(a, b));
  float H = atan(b, a);
  return vec3(L, C, H);
}

vec3 LCH_TO_SRGB(vec3 lch) {
  float a = lch.y * cos(lch.z);
  float b = lch.y * sin(lch.z);
  float fy = (lch.x + 16.0) / 116.0;
  float fx = fy + a / 500.0;
  float fz = fy - b / 200.0;
  vec3 xyz = vec3(lab_finv(fx), lab_finv(fy), lab_finv(fz)) * D65;
  return linear_to_srgb(XYZ_TO_RGB * xyz);
}

float vec2ToAngle(vec2 v) {
  float a = atan(v.y, v.x);
  if (a < 0.0) a += 2.0 * PI;
  return a;
}
float safeAsin(float x) {
  // asin is undefined for |x| > 1, which happens just outside the silhouette
  // where the bevel ratio overshoots. Unclamped this yields NaN and eats the
  // entire edge band.
  return asin(clamp(x, -1.0, 1.0));
}`;

  // Shape SDF. Rounded-rect with the corner arc replaced by a superellipse
  // Lp-norm — that is what gives a real squircle rather than a circular fillet.
  var LIB_SDF = `
uniform int   u_shapeCount;
uniform vec2  u_shapeCenter[${MAX_SHAPES}];  // px, y-up, device pixels
uniform vec2  u_shapeSize[${MAX_SHAPES}];    // px, device pixels
uniform float u_shapeRadius[${MAX_SHAPES}];  // px, device pixels
uniform float u_shapeRoundness[${MAX_SHAPES}];
uniform float u_mergeRate;
uniform vec2  u_resolution;    // device px
uniform vec2  u_resolution1x;  // CSS px
uniform float u_dpr;

float superellipseCorner(vec2 p, float r, float n) {
  p = abs(p);
  // n == 2 is an exact circle; pow() is both slower and less accurate there.
  if (abs(n - 2.0) < 0.001) return length(p) - r;
  return pow(pow(p.x, n) + pow(p.y, n), 1.0 / n) - r;
}

float roundedRectSDF(vec2 p, vec2 halfSize, float cr, float n) {
  cr = min(cr, min(halfSize.x, halfSize.y));
  vec2 d = abs(p) - halfSize;
  if (d.x > -cr && d.y > -cr) {
    vec2 cc = sign(p) * (halfSize - vec2(cr));
    return superellipseCorner(p - cc, cr, n);
  }
  return min(max(d.x, d.y), 0.0) + length(max(d, 0.0));
}

// IQ's quadratic polynomial smooth-min — the blob merge.
float smin(float a, float b, float k) {
  if (k <= 0.0) return min(a, b);
  float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

// All SDF math lives in units of "fraction of viewport height". Keeping one
// consistent scale is what makes the bevel/merge parameters resolution
// independent; aspect is corrected only when converting to a UV offset.
float sceneSDF(vec2 frag, vec2 shift) {
  float d = 1e9;
  for (int i = 0; i < ${MAX_SHAPES}; i++) {
    if (i >= u_shapeCount) break;
    vec2 p = (frag - (u_shapeCenter[i] + shift)) / u_resolution.y;
    float di = roundedRectSDF(
      p,
      u_shapeSize[i] * 0.5 / u_resolution.y,
      u_shapeRadius[i] / u_resolution.y,
      u_shapeRoundness[i]
    );
    d = (i == 0) ? di : smin(d, di, u_mergeRate);
  }
  return d;
}`;

  // ═══════════════════════════════════════════════════════════════════════
  // Background pass — procedural patterns or a texture, plus the drop shadow.
  // The shadow is drawn here (not in the main pass) so the glass refracts its
  // own shadow, exactly as real glass sitting above a surface would.
  // ═══════════════════════════════════════════════════════════════════════
  var FRAG_BG = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 fragColor;

${LIB_COLOR}
${LIB_SDF}

uniform int       u_bgType;         // 0 gradient, 1 checker, 2 stripes, 3 texture
uniform sampler2D u_bgTexture;
uniform float     u_bgTextureRatio;
uniform int       u_bgTextureReady;
uniform float     u_time;
uniform float     u_shadowExpand;
uniform float     u_shadowFactor;
uniform vec2      u_shadowOffset;   // device px

vec2 getCoverUV(vec2 uv, float canvasAspect, float texAspect) {
  if (canvasAspect > texAspect) {
    float s = texAspect / canvasAspect;
    uv.y = uv.y * s + 0.5 - 0.5 * s;
  } else {
    float s = canvasAspect / texAspect;
    uv.x = uv.x * s + 0.5 - 0.5 * s;
  }
  return uv;
}

vec3 proceduralGradient(vec2 uv) {
  // Smooth multi-blob gradient. High chroma and plenty of mid-frequency
  // structure, because refraction over flat colour is invisible.
  vec2 p = uv * vec2(u_resolution1x.x / u_resolution1x.y, 1.0);
  float t = u_time * 0.08;
  vec3 c = vec3(0.05, 0.06, 0.12);
  c += vec3(0.95, 0.28, 0.35) * exp(-3.2 * length(p - vec2(0.35 + 0.10 * sin(t),        0.30 + 0.08 * cos(t * 1.3))));
  c += vec3(0.10, 0.75, 0.92) * exp(-3.0 * length(p - vec2(1.05 + 0.12 * cos(t * 0.9),  0.28 + 0.10 * sin(t * 1.1))));
  c += vec3(0.60, 0.25, 0.95) * exp(-3.4 * length(p - vec2(0.45 + 0.09 * sin(t * 1.4),  0.82 + 0.07 * cos(t))));
  c += vec3(0.98, 0.72, 0.15) * exp(-3.1 * length(p - vec2(1.15 + 0.11 * cos(t * 1.2),  0.80 + 0.09 * sin(t * 0.8))));
  return c;
}

vec3 checker(vec2 uv) {
  vec2 g = floor(uv * u_resolution1x / 32.0);
  float m = mod(g.x + g.y, 2.0);
  return mix(vec3(0.10, 0.11, 0.14), vec3(0.92, 0.93, 0.96), m);
}

vec3 stripes(vec2 uv) {
  // Deliberately high-frequency: the clearest possible readout of refraction.
  float x = uv.x * u_resolution1x.x;
  float s = step(0.5, fract(x / 24.0));
  vec3 a = mix(vec3(0.98, 0.99, 1.0), vec3(0.04, 0.05, 0.09), s);
  float y = step(0.5, fract(uv.y * u_resolution1x.y / 24.0));
  return mix(a, a.brg, y * 0.55);
}

void main() {
  vec3 bg;
  if (u_bgType == 3 && u_bgTextureReady == 1) {
    float canvasAspect = u_resolution1x.x / u_resolution1x.y;
    bg = texture(u_bgTexture, getCoverUV(v_uv, canvasAspect, u_bgTextureRatio)).rgb;
  } else if (u_bgType == 1) {
    bg = checker(v_uv);
  } else if (u_bgType == 2) {
    bg = stripes(v_uv);
  } else {
    bg = proceduralGradient(v_uv);
  }

  if (u_shadowFactor > 0.0) {
    // Distance to the *offset* silhouette, in CSS px. Positive outside.
    float sd = sceneSDF(gl_FragCoord.xy, u_shadowOffset) * u_resolution1x.y;
    // One-sided: the shadow lives outside the offset shape and decays with
    // distance. Using abs(sd) instead would darken the shape's own edge, which
    // reads as a bright halo once the glass is drawn over it.
    float sh = exp(-max(sd, 0.0) / max(0.001, u_shadowExpand)) * 0.6 * u_shadowFactor;
    // Multiplicative so it darkens proportionally instead of crushing to black
    // on light backgrounds.
    bg *= (1.0 - clamp(sh, 0.0, 1.0));
  }
  fragColor = vec4(max(bg, vec3(0.0)), 1.0);
}`;

  // ═══════════════════════════════════════════════════════════════════════
  // Separable Gaussian blur.
  //
  // Two optimisations over the reference, which blurs at full resolution with
  // up to 401 taps per pass:
  //   1. Runs at 1/2 or 1/4 resolution. The blurred texture is only ever read
  //      through a lens, so the lost detail is unobservable.
  //   2. Linear-sampled taps — each fetch lands *between* two texels so
  //      hardware bilinear filtering gives us two weighted samples for one
  //      memory access, halving the tap count.
  // ═══════════════════════════════════════════════════════════════════════
  var FRAG_BLUR = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 fragColor;

uniform sampler2D u_tex;
uniform vec2  u_texelSize;
uniform vec2  u_direction;   // (1,0) horizontal, (0,1) vertical
uniform int   u_taps;
uniform float u_weights[${MAX_BLUR_RADIUS + 1}];
uniform float u_offsets[${MAX_BLUR_RADIUS + 1}];

void main() {
  vec4 c = texture(u_tex, v_uv) * u_weights[0];
  for (int i = 1; i <= ${MAX_BLUR_RADIUS}; i++) {
    if (i >= u_taps) break;
    vec2 o = u_direction * u_offsets[i] * u_texelSize;
    c += texture(u_tex, v_uv + o) * u_weights[i];
    c += texture(u_tex, v_uv - o) * u_weights[i];
  }
  fragColor = c;
}`;

  // ═══════════════════════════════════════════════════════════════════════
  // Main pass — the actual glass.
  // ═══════════════════════════════════════════════════════════════════════
  var FRAG_MAIN = `#version 300 es
precision highp float;
in vec2 v_uv;
out vec4 fragColor;

${LIB_COLOR}
${LIB_SDF}

uniform sampler2D u_bg;
uniform sampler2D u_blurredBg;

uniform float u_refThickness;
uniform float u_refIor;
uniform float u_refDispersion;
uniform float u_fresnelRange;
uniform float u_fresnelHardness;
uniform float u_fresnelFactor;
uniform float u_glareRange;
uniform float u_glareHardness;
uniform float u_glareFactor;
uniform float u_glareConvergence;
uniform float u_glareOppositeFactor;
uniform float u_glareAngle;
uniform int   u_blurEdge;
uniform vec4  u_tint;

const float N_R = 1.0 - 0.02;
const float N_G = 1.0;
const float N_B = 1.0 + 0.02;

// Screen-space gradient of the SDF.
//
// Deliberately NOT normalised, and scaled by sqrt(2)*1000. Because sceneSDF
// divides by resolution.y, the raw per-pixel gradient magnitude is ~1/height;
// the scale brings length() to ~1 on a typical viewport. That magnitude is
// load-bearing — it is multiplied into the Fresnel and glare mix weights,
// where it naturally fades highlights across the smooth-min seam and in flat
// interiors. Normalising this flattens all the lighting.
vec2 getNormal(vec2 frag) {
  vec2 h = vec2(max(abs(dFdx(frag.x)), 0.0001), max(abs(dFdy(frag.y)), 0.0001));
  vec2 grad = vec2(
    sceneSDF(frag + vec2(h.x, 0.0), vec2(0.0)) - sceneSDF(frag - vec2(h.x, 0.0), vec2(0.0)),
    sceneSDF(frag + vec2(0.0, h.y), vec2(0.0)) - sceneSDF(frag - vec2(0.0, h.y), vec2(0.0))
  ) / (2.0 * h);
  return grad * 1.414213562 * 1000.0;
}

// Three wavelength samples. Each colour channel is fetched at its own
// displacement, from both the sharp and the blurred background, giving true
// prismatic fringing at the rim instead of a uniform colour shift.
vec3 sampleDispersed(vec2 offset, float mixRate) {
  float sR = 1.0 - (N_R - 1.0) * u_refDispersion;
  float sG = 1.0 - (N_G - 1.0) * u_refDispersion;
  float sB = 1.0 - (N_B - 1.0) * u_refDispersion;

  vec3 sharp = vec3(
    texture(u_bg, v_uv + offset * sR).r,
    texture(u_bg, v_uv + offset * sG).g,
    texture(u_bg, v_uv + offset * sB).b
  );
  if (mixRate <= 0.0) return sharp;

  vec3 blurred = vec3(
    texture(u_blurredBg, v_uv + offset * sR).r,
    texture(u_blurredBg, v_uv + offset * sG).g,
    texture(u_blurredBg, v_uv + offset * sB).b
  );
  return mix(sharp, blurred, mixRate);
}

void main() {
  vec2 frag = gl_FragCoord.xy;
  float d = sceneSDF(frag, vec2(0.0));

  // Evaluate slightly outside the silhouette so the closing smoothstep has
  // real glass data on both sides to anti-alias against.
  if (d >= 0.005) {
    fragColor = texture(u_bg, v_uv);
    return;
  }

  float depthPx = -d * u_resolution1x.y;          // how far inside, CSS px
  vec2  normal  = getNormal(frag);

  // ── Refraction: Snell's law across an analytic bevel ──────────────────
  // xR runs 1 at the rim to 0 at the inner edge of the bevel band. The
  // squared argument to asin is what shapes the profile: a true spherical
  // bevel would be asin(xR), and the square biases curvature hard toward the
  // rim, producing the thin intense edge band that reads as thick glass.
  float edgeFactor = 0.0;
  if (depthPx < u_refThickness) {
    float xR     = 1.0 - depthPx / max(0.001, u_refThickness);
    float thetaI = safeAsin(pow(clamp(xR, 0.0, 1.0), 2.0));
    float thetaT = safeAsin(sin(thetaI) / max(1.0, u_refIor));
    edgeFactor   = -tan(thetaT - thetaI);
  }

  // Aspect correction: the gradient is in height-normalised units, so only x
  // needs rescaling to land in UV space.
  vec2 aspect = vec2(u_resolution.y / (u_resolution1x.x * u_dpr), 1.0);
  vec2 offset = -normal * edgeFactor * 0.05 * u_dpr * aspect;

  // Blur weighting. edgeH is 0 at the rim, 1 at the inner edge of the bevel.
  // Diffusion belongs where the glass is *curved* — light scatters crossing a
  // sloped surface — so the bevel blurs and the flat centre stays clear.
  // u_blurEdge frosts the whole pane instead, for a translucent panel look.
  float edgeH   = clamp(depthPx / max(0.001, u_refThickness), 0.0, 1.0);
  float mixRate = u_blurEdge == 1 ? 1.0 : (1.0 - edgeH);
  vec3  refracted = sampleDispersed(offset, mixRate);

  // ── Body tint ─────────────────────────────────────────────────────────
  vec3 outColor = mix(refracted, u_tint.rgb, u_tint.a * 0.8);

  // ── Fresnel and glare falloff ─────────────────────────────────────────
  // A quintic ramp on the signed distance, not a physical Schlick term. The
  // reference tried Schlick and the full Fresnel equations and rejected both:
  // a distance ramp gives art-directable control over where the rim lights up.
  float dPx = d * u_resolution1x.y;   // negative inside
  float fresnelFactor = clamp(
    pow(1.0 + dPx / 1500.0 * pow(500.0 / max(0.001, u_fresnelRange), 2.0)
          + u_fresnelHardness, 5.0), 0.0, 1.0);
  float glareGeoFactor = clamp(
    pow(1.0 + dPx / 1500.0 * pow(500.0 / max(0.001, u_glareRange), 2.0)
          + u_glareHardness, 5.0), 0.0, 1.0);

  // Doubling the angle creates two opposing highlight lobes — the signature
  // liquid-glass look, where light catches both the near and far rim.
  float ga = (vec2ToAngle(normalize(normal)) - PI / 4.0 + u_glareAngle) * 2.0;
  bool farSide = (ga > PI * 1.5 && ga < PI * 3.5) || ga < -PI * 0.5;
  float glareAngleFactor = (0.5 + sin(ga) * 0.5)
    * (farSide ? 1.2 * u_glareOppositeFactor : 1.2)
    * u_glareFactor;
  glareAngleFactor = clamp(
    pow(max(glareAngleFactor, 0.0), 0.1 + u_glareConvergence * 2.0), 0.0, 1.0);

  float nlen = length(normal);

  // ── Composite highlights in LCH ───────────────────────────────────────
  vec3 fLCH = SRGB_TO_LCH(mix(vec3(1.0), u_tint.rgb, u_tint.a * 0.5));
  fLCH.x = clamp(fLCH.x + 20.0 * fresnelFactor * u_fresnelFactor, 0.0, 100.0);
  outColor = mix(outColor, LCH_TO_SRGB(fLCH),
                 clamp(fresnelFactor * u_fresnelFactor * 0.7 * nlen, 0.0, 1.0));

  // Glare's base is the refracted background, so highlights inherit the
  // colour behind the glass. L is pushed far past 100 then clamped to 120 —
  // intentionally superwhite, which is what makes it read as a specular hit.
  vec3 gLCH = SRGB_TO_LCH(mix(refracted, u_tint.rgb, u_tint.a * 0.5));
  float gAmt = glareAngleFactor * glareGeoFactor;
  gLCH.x = clamp(gLCH.x + 150.0 * gAmt, 0.0, 120.0);
  gLCH.y = gLCH.y + 30.0 * gAmt;
  outColor = mix(outColor, LCH_TO_SRGB(gLCH), clamp(gAmt * nlen, 0.0, 1.0));

  // Anti-alias the silhouette against the sharp background.
  outColor = mix(outColor, texture(u_bg, v_uv).rgb, smoothstep(-0.001, 0.001, d));
  fragColor = vec4(outColor, 1.0);
}`;

  // ═══════════════════════════════════════════════════════════════════════
  // GL helpers
  // ═══════════════════════════════════════════════════════════════════════

  function compile(gl, type, src, label) {
    var sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      var log = gl.getShaderInfoLog(sh);
      var lines = src.split('\n').map(function (l, i) {
        return (i + 1) + ': ' + l;
      });
      // Surface the offending line — a raw GLSL log without source context is
      // near-useless when the shader is assembled from template pieces.
      var m = /:(\d+):/.exec(log || '');
      var ctx = '';
      if (m) {
        var n = parseInt(m[1], 10);
        ctx = '\n' + lines.slice(Math.max(0, n - 4), n + 3).join('\n');
      }
      gl.deleteShader(sh);
      throw new Error('[LiquidGlass] ' + label + ' compile failed: ' + log + ctx);
    }
    return sh;
  }

  function program(gl, fragSrc, label) {
    var vs = compile(gl, gl.VERTEX_SHADER, VERT, label + ' vertex');
    var fs = compile(gl, gl.FRAGMENT_SHADER, fragSrc, label + ' fragment');
    var p = gl.createProgram();
    gl.attachShader(p, vs);
    gl.attachShader(p, fs);
    gl.linkProgram(p);
    gl.deleteShader(vs);
    gl.deleteShader(fs);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      var log = gl.getProgramInfoLog(p);
      gl.deleteProgram(p);
      throw new Error('[LiquidGlass] ' + label + ' link failed: ' + log);
    }
    return p;
  }

  // Uniform locations are resolved once and cached; getUniformLocation is a
  // surprisingly hot call if done per-frame.
  function uniformCache(gl, prog) {
    var cache = {};
    return function (name) {
      if (!(name in cache)) cache[name] = gl.getUniformLocation(prog, name);
      return cache[name];
    };
  }

  function makeFBO(gl, w, h, fmt) {
    var tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, fmt.internal, w, h, 0, fmt.format, fmt.type, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    var fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    var ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    if (!ok) {
      gl.deleteFramebuffer(fb);
      gl.deleteTexture(tex);
      return null;
    }
    return { fb: fb, tex: tex, w: w, h: h };
  }

  function freeFBO(gl, f) {
    if (!f) return;
    gl.deleteFramebuffer(f.fb);
    gl.deleteTexture(f.tex);
  }

  // Linear-sampled Gaussian: pair up adjacent texels so hardware bilinear
  // filtering resolves two samples per fetch. Weight is the pair's sum; offset
  // is the weighted centroid between them.
  function gaussianKernel(radius) {
    radius = Math.max(0, Math.round(radius));
    if (radius === 0) return { weights: [1], offsets: [0], taps: 1 };
    var sigma = Math.max(0.5, radius / 3);
    var raw = [];
    var sum = 0;
    for (var i = 0; i <= radius; i++) {
      var wt = Math.exp(-0.5 * (i * i) / (sigma * sigma));
      raw.push(wt);
      sum += i === 0 ? wt : wt * 2;
    }
    for (var j = 0; j < raw.length; j++) raw[j] /= sum;

    var weights = [raw[0]];
    var offsets = [0];
    for (var k = 1; k < raw.length; k += 2) {
      var w1 = raw[k];
      var w2 = k + 1 < raw.length ? raw[k + 1] : 0;
      var w = w1 + w2;
      weights.push(w);
      offsets.push(w > 0 ? (k * w1 + (k + 1) * w2) / w : k);
    }
    if (weights.length > MAX_BLUR_RADIUS + 1) {
      weights.length = MAX_BLUR_RADIUS + 1;
      offsets.length = MAX_BLUR_RADIUS + 1;
    }
    return { weights: weights, offsets: offsets, taps: weights.length };
  }

  // ═══════════════════════════════════════════════════════════════════════
  // Spring — semi-implicit Euler. Stable at these stiffnesses and far cheaper
  // than evaluating the closed-form solution per frame.
  // ═══════════════════════════════════════════════════════════════════════
  function Spring(k, c) {
    this.k = k; this.c = c;
    this.x = 0; this.v = 0; this.target = 0;
    this._init = false;
  }
  Spring.prototype.set = function (v) {
    if (!this._init) { this.x = v; this._init = true; }
    this.target = v;
  };
  Spring.prototype.snap = function (v) {
    this.x = this.target = v; this.v = 0; this._init = true;
  };
  Spring.prototype.step = function (dt) {
    // Sub-step so a long frame can't blow the integrator up.
    var steps = Math.min(4, Math.max(1, Math.ceil(dt / 0.008)));
    var h = dt / steps;
    for (var i = 0; i < steps; i++) {
      var a = -this.k * (this.x - this.target) - this.c * this.v;
      this.v += a * h;
      this.x += this.v * h;
    }
    return this.x;
  };
  Spring.prototype.settled = function () {
    return Math.abs(this.v) < 0.01 && Math.abs(this.x - this.target) < 0.01;
  };

  // ═══════════════════════════════════════════════════════════════════════
  // Background sources
  //
  // A source's only contract: own a GL texture, report its aspect ratio and
  // readiness, and say whether it changed since the last frame. That keeps
  // "where do the pixels come from" fully decoupled from the optics, so the
  // DOM-capture adapter is just another source rather than a special case.
  // ═══════════════════════════════════════════════════════════════════════

  function makeTexture(gl) {
    var t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA,
      gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255]));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    return t;
  }

  function upload(gl, tex, el, flipY) {
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, flipY ? 1 : 0);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, el);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
  }

  // type 0 = procedural gradient, 1 = checker, 2 = stripes, 3 = texture
  function ProceduralSource(kind) {
    this.bgType = kind === 'checker' ? 1 : kind === 'stripes' ? 2 : 0;
    this.ready = true;
    this.ratio = 1;
    this.animated = this.bgType === 0; // gradient drifts over time
  }
  ProceduralSource.prototype.attach = function () {};
  ProceduralSource.prototype.update = function () { return this.animated; };
  ProceduralSource.prototype.destroy = function () {};

  function ImageSource(src) {
    this.bgType = 3;
    this.ready = false;
    this.ratio = 1;
    this.animated = false;
    this._src = src;
    this._dirty = false;
  }
  ImageSource.prototype.attach = function (gl) {
    var self = this;
    this.gl = gl;
    this.texture = makeTexture(gl);
    var img = new Image();
    // Needed for any cross-origin background, else texImage2D throws on a
    // tainted source.
    img.crossOrigin = 'anonymous';
    img.onload = function () {
      self.ratio = img.naturalWidth / img.naturalHeight;
      upload(gl, self.texture, img, true);
      self.ready = true;
      self._dirty = true;
      if (self.onready) self.onready();
    };
    img.onerror = function () {
      console.warn('[LiquidGlass] background image failed to load:', self._src);
    };
    img.src = this._src;
    this._img = img;
  };
  ImageSource.prototype.update = function () {
    var d = this._dirty; this._dirty = false; return d;
  };
  ImageSource.prototype.destroy = function () {
    if (this.texture) this.gl.deleteTexture(this.texture);
    if (this._img) { this._img.onload = this._img.onerror = null; }
  };

  function VideoSource(src) {
    this.bgType = 3;
    this.ready = false;
    this.ratio = 16 / 9;
    this.animated = true;
    this._src = src;
    this._lastTime = -1;
  }
  VideoSource.prototype.attach = function (gl) {
    var self = this;
    this.gl = gl;
    this.texture = makeTexture(gl);
    var v;
    if (typeof this._src === 'string') {
      v = document.createElement('video');
      v.src = this._src;
      v.crossOrigin = 'anonymous';
      v.loop = true; v.muted = true; v.playsInline = true;
      v.play().catch(function () {
        console.warn('[LiquidGlass] video autoplay blocked; call play() after a gesture');
      });
      this._owned = true;
    } else {
      v = this._src; // caller-supplied <video>
    }
    this._video = v;
    var onMeta = function () {
      self.ratio = v.videoWidth / v.videoHeight;
      self.ready = true;
    };
    if (v.readyState >= 1) onMeta(); else v.addEventListener('loadedmetadata', onMeta);
    this._onMeta = onMeta;
  };
  VideoSource.prototype.update = function () {
    var v = this._video;
    if (!v || v.readyState < 2) return false;
    // Only re-upload on a genuinely new frame. Without this check a paused
    // video would re-upload (and re-mipmap) every rAF for nothing.
    if (v.currentTime === this._lastTime) return false;
    this._lastTime = v.currentTime;
    if (!this.ready) { this.ratio = v.videoWidth / v.videoHeight; this.ready = true; }
    upload(this.gl, this.texture, v, true);
    return true;
  };
  VideoSource.prototype.destroy = function () {
    if (this._video && this._onMeta) {
      this._video.removeEventListener('loadedmetadata', this._onMeta);
    }
    if (this._owned && this._video) { this._video.pause(); this._video.src = ''; }
    if (this.texture) this.gl.deleteTexture(this.texture);
  };

  function CanvasSource(canvas) {
    this.bgType = 3;
    this.ready = true;
    this.animated = false;
    this._canvas = canvas;
    this.ratio = canvas.width / canvas.height;
    this._dirty = true;
  }
  CanvasSource.prototype.attach = function (gl) {
    this.gl = gl;
    this.texture = makeTexture(gl);
  };
  CanvasSource.prototype.markChanged = function () { this._dirty = true; };
  CanvasSource.prototype.update = function () {
    if (!this._dirty) return false;
    this._dirty = false;
    this.ratio = this._canvas.width / this._canvas.height;
    upload(this.gl, this.texture, this._canvas, true);
    return true;
  };
  CanvasSource.prototype.destroy = function () {
    if (this.texture) this.gl.deleteTexture(this.texture);
  };

  /**
   * DOM capture — opt-in, with real caveats.
   *
   * Rasterises a DOM subtree via SVG <foreignObject> into a texture. Unlike
   * html2canvas this needs no dependency, but it carries the same fundamental
   * limits, and you should know them before reaching for it:
   *
   *   - Content under the glass is a SNAPSHOT. Live text, carets, videos and
   *     CSS animations are frozen until you call markChanged().
   *   - External images need CORS headers; web fonts must be embedded as data
   *     URIs or they render with a fallback face.
   *   - Cross-origin iframes and <canvas> subtrees will not rasterise.
   *   - Capture cost scales with DOM complexity; it is not a per-frame option.
   *
   * The texture route (image/video/canvas/gradient) is strictly better whenever
   * you control the backdrop. Use this only when the glass genuinely must sit
   * over live page content.
   */
  function DOMSource(element, opts) {
    this.bgType = 3;
    this.ready = false;
    this.animated = false;
    this.ratio = 1;
    this._el = element;
    this._opts = opts || {};
    this._dirty = false;
    this._busy = false;
  }
  DOMSource.prototype.attach = function (gl) {
    this.gl = gl;
    this.texture = makeTexture(gl);
    this.capture();
  };
  DOMSource.prototype.markChanged = function () { this.capture(); };
  DOMSource.prototype.capture = function () {
    var self = this;
    if (this._busy) return;
    var el = this._el;
    var rect = el.getBoundingClientRect();
    var w = Math.max(1, Math.round(rect.width));
    var h = Math.max(1, Math.round(rect.height));
    if (!w || !h) return;
    this._busy = true;

    var clone = el.cloneNode(true);
    inlineStyles(el, clone);
    var xhtml = new XMLSerializer().serializeToString(clone);
    var svg =
      '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '">' +
      '<foreignObject width="100%" height="100%">' +
      '<div xmlns="http://www.w3.org/1999/xhtml">' + xhtml + '</div>' +
      '</foreignObject></svg>';

    var img = new Image();
    img.onload = function () {
      self.ratio = w / h;
      upload(self.gl, self.texture, img, true);
      self.ready = true;
      self._dirty = true;
      self._busy = false;
      if (self.onready) self.onready();
    };
    img.onerror = function () {
      self._busy = false;
      console.warn('[LiquidGlass] DOM capture failed. Common causes: ' +
        'cross-origin images without CORS, or unsupported CSS in the subtree.');
    };
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  };
  DOMSource.prototype.update = function () {
    var d = this._dirty; this._dirty = false; return d;
  };
  DOMSource.prototype.destroy = function () {
    if (this.texture) this.gl.deleteTexture(this.texture);
  };

  // foreignObject rasterisation ignores external stylesheets, so computed
  // styles have to be baked onto the clone inline.
  function inlineStyles(src, dst) {
    var cs = getComputedStyle(src);
    var css = '';
    for (var i = 0; i < cs.length; i++) {
      var prop = cs[i];
      css += prop + ':' + cs.getPropertyValue(prop) + ';';
    }
    dst.setAttribute('style', css);
    var sc = src.children, dc = dst.children;
    for (var j = 0; j < sc.length && j < dc.length; j++) inlineStyles(sc[j], dc[j]);
  }

  function buildSource(cfg) {
    if (!cfg) return new ProceduralSource('gradient');
    if (cfg.element || cfg.type === 'dom') return new DOMSource(cfg.element, cfg);
    if (cfg.canvas || cfg.type === 'canvas') return new CanvasSource(cfg.canvas);
    if (cfg.type === 'video') return new VideoSource(cfg.src);
    if (cfg.type === 'image') return new ImageSource(cfg.src);
    return new ProceduralSource(cfg.type || 'gradient');
  }

  // ═══════════════════════════════════════════════════════════════════════
  // Renderer
  // ═══════════════════════════════════════════════════════════════════════

  function Glass(canvas, options) {
    if (!canvas || !canvas.getContext) {
      throw new Error('[LiquidGlass] create() needs a <canvas> element');
    }
    this.canvas = canvas;
    this.o = deepMerge(DEFAULTS, options);

    var gl = canvas.getContext('webgl2', {
      alpha: false, antialias: false, depth: false, stencil: false,
      premultipliedAlpha: false, preserveDrawingBuffer: false,
      powerPreference: 'high-performance'
    });
    if (!gl) {
      this.supported = false;
      this._cssFallback();
      return;
    }
    this.gl = gl;
    this.supported = true;

    // Float FBOs keep the blur and the LCH highlight maths out of 8-bit
    // quantisation. Without the extension we fall back to RGBA8, which shows
    // mild banding in the glare but is otherwise correct.
    var floatOk = !!gl.getExtension('EXT_color_buffer_float');
    this.fmt = floatOk
      ? { internal: gl.RGBA16F, format: gl.RGBA, type: gl.HALF_FLOAT }
      : { internal: gl.RGBA8, format: gl.RGBA, type: gl.UNSIGNED_BYTE };
    this.floatFBO = floatOk;

    this._initGL();
    this._initState();
    this._bindEvents();
    this.resize();
    this._loop();
  }

  Glass.prototype._cssFallback = function () {
    // No WebGL2 at all. Rather than render nothing, leave a frosted panel so
    // layouts that depend on the element still read correctly.
    var c = this.canvas;
    c.style.background = 'rgba(255,255,255,0.10)';
    c.style.backdropFilter = 'blur(12px) saturate(1.6)';
    c.style.webkitBackdropFilter = 'blur(12px) saturate(1.6)';
    console.warn('[LiquidGlass] WebGL2 unavailable — using CSS blur fallback.');
  };

  Glass.prototype._initGL = function () {
    var gl = this.gl;

    this.quad = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.bufferData(gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);

    this.progBg = program(gl, FRAG_BG, 'bg');
    this.progBlur = program(gl, FRAG_BLUR, 'blur');
    this.progMain = program(gl, FRAG_MAIN, 'main');
    this.uBg = uniformCache(gl, this.progBg);
    this.uBlur = uniformCache(gl, this.progBlur);
    this.uMain = uniformCache(gl, this.progMain);

    this.fboBg = null;
    this.fboBlurA = null;
    this.fboBlurB = null;

    this.source = buildSource(this.o.background);
    this.source.attach(gl);
    var self = this;
    this.source.onready = function () { self.invalidate(); };
  };

  Glass.prototype._initState = function () {
    var s = this.o.spring;
    var reduce = this.o.reducedMotion === true ||
      (this.o.reducedMotion === 'auto' && window.matchMedia &&
       window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    this.reduceMotion = reduce;

    this.springs = [];
    for (var i = 0; i < MAX_SHAPES; i++) {
      this.springs.push({
        x: new Spring(s.stiffness, s.damping),
        y: new Spring(s.stiffness, s.damping),
        vx: 0, vy: 0, lastX: 0, lastY: 0
      });
    }
    this.pointer = { x: 0, y: 0, inside: false };
    this.time = 0;
    this._dirty = true;
    this._visible = true;
    this._frames = 0;
    this._fps = 0;
    this._fpsT = 0;
    this._kernel = gaussianKernel(this.o.blur.radius);
  };

  /** Mark the scene as needing a redraw. Cheap; call freely. */
  Glass.prototype.invalidate = function () { this._dirty = true; };

  Glass.prototype._bindEvents = function () {
    var self = this, c = this.canvas;

    this._onPointer = function (e) {
      var r = c.getBoundingClientRect();
      self.pointer.x = (e.clientX - r.left);
      self.pointer.y = (e.clientY - r.top);
      self.pointer.inside = true;
      self.invalidate();
    };
    this._onLeave = function () { self.pointer.inside = false; self.invalidate(); };

    if (this.o.followPointer) {
      c.addEventListener('pointermove', this._onPointer, { passive: true });
      c.addEventListener('pointerleave', this._onLeave, { passive: true });
    }

    this._onResize = function () { self.resize(); };
    window.addEventListener('resize', this._onResize);

    if (typeof ResizeObserver !== 'undefined') {
      this._ro = new ResizeObserver(function () { self.resize(); });
      this._ro.observe(c);
    }

    // Never burn GPU on an off-screen canvas.
    if (typeof IntersectionObserver !== 'undefined') {
      this._io = new IntersectionObserver(function (en) {
        self._visible = en[0].isIntersecting;
        if (self._visible) self.invalidate();
      }, { rootMargin: '64px' });
      this._io.observe(c);
    }

    this._onLost = function (e) {
      // preventDefault is what makes the context eligible for restoration at
      // all; without it the canvas is permanently dead.
      e.preventDefault();
      self._lost = true;
      // Browsers cap live contexts (~16 in Chrome) and evict the oldest, so a
      // page with many glass canvases can lose one through no fault of its own.
      // Ask for it back — the event alone does not trigger a restore.
      var ext = self.gl && self.gl.getExtension('WEBGL_lose_context');
      if (ext && !self._destroyed) {
        setTimeout(function () {
          if (!self._destroyed && self._lost) {
            try { ext.restoreContext(); } catch (err) { /* not restorable */ }
          }
        }, 250);
      }
      console.warn('[LiquidGlass] WebGL context lost; attempting restore');
    };
    this._onRestored = function () {
      self._lost = false;
      // Every GL object died with the context: reallocate programs, buffers,
      // textures and FBOs from scratch. w is cleared so resize() cannot early
      // out on unchanged dimensions.
      self._initGL();
      self.w = -1;
      self.resize();
      console.warn('[LiquidGlass] context restored');
    };
    c.addEventListener('webglcontextlost', this._onLost);
    c.addEventListener('webglcontextrestored', this._onRestored);
  };

  Glass.prototype.resize = function () {
    if (!this.supported) return;
    var c = this.canvas, gl = this.gl;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var rect = c.getBoundingClientRect();
    var cssW = Math.max(1, Math.round(rect.width || c.clientWidth || 300));
    var cssH = Math.max(1, Math.round(rect.height || c.clientHeight || 150));
    var w = Math.max(1, Math.round(cssW * dpr));
    var h = Math.max(1, Math.round(cssH * dpr));
    if (w === this.w && h === this.h && dpr === this.dpr) return;

    this.dpr = dpr; this.w = w; this.h = h; this.cssW = cssW; this.cssH = cssH;
    c.width = w; c.height = h;

    var q = this.o.blur.quality;
    var scale = q === 'full' ? 1 : q === 'quarter' ? 0.25 : 0.5;
    var bw = Math.max(1, Math.round(w * scale));
    var bh = Math.max(1, Math.round(h * scale));

    freeFBO(gl, this.fboBg); freeFBO(gl, this.fboBlurA); freeFBO(gl, this.fboBlurB);
    this.fboBg = makeFBO(gl, w, h, this.fmt);
    this.fboBlurA = makeFBO(gl, bw, bh, this.fmt);
    this.fboBlurB = makeFBO(gl, bw, bh, this.fmt);
    if (!this.fboBg || !this.fboBlurA || !this.fboBlurB) {
      // Float attachments can validate in isolation yet fail at this size.
      // Retry once at 8-bit before giving up.
      if (this.floatFBO) {
        this.floatFBO = false;
        this.fmt = { internal: gl.RGBA8, format: gl.RGBA, type: gl.UNSIGNED_BYTE };
        console.warn('[LiquidGlass] float FBO unavailable at this size; using RGBA8');
        this.w = -1;
        return this.resize();
      }
      throw new Error('[LiquidGlass] could not allocate framebuffers');
    }
    this.invalidate();
  };

  Glass.prototype._resolveShapes = function () {
    var out = [];
    var list = this.o.shapes.slice(0, MAX_SHAPES);
    for (var i = 0; i < list.length; i++) {
      var s = list[i];
      var cx = parsePos(s.x, this.cssW);
      var cy = parsePos(s.y, this.cssH);
      var w = s.width, h = s.height;

      var follow = s.followPointer !== undefined ? s.followPointer
        : (this.o.followPointer && i === list.length - 1 && list.length > 1);

      var sp = this.springs[i];
      if (follow && this.pointer.inside) {
        sp.x.set(this.pointer.x); sp.y.set(this.pointer.y);
      } else if (follow) {
        sp.x.set(cx); sp.y.set(cy);
      } else {
        sp.x.snap(cx); sp.y.snap(cy);
      }

      // Velocity-driven squash/stretch is what makes the shape feel like a
      // liquid volume rather than a rigid sprite: it inflates along whichever
      // axis it is travelling.
      var stretch = this.reduceMotion ? 0 : this.o.spring.sizeFactor / 100;
      var sw = w + Math.abs(sp.vx) * w * stretch;
      var sh = h + Math.abs(sp.vy) * h * stretch;

      var radiusPx = Math.min(sw, sh) / 2 * (s.radius / 100);
      out.push({
        // gl_FragCoord is y-up; CSS is y-down.
        cx: sp.x.x * this.dpr,
        cy: (this.cssH - sp.y.x) * this.dpr,
        w: sw * this.dpr,
        h: sh * this.dpr,
        r: radiusPx * this.dpr,
        n: s.roundness,
        follow: follow
      });
    }
    return out;
  };

  function parsePos(v, extent) {
    if (typeof v === 'number') return v;
    if (typeof v === 'string' && v.indexOf('%') !== -1) {
      return parseFloat(v) / 100 * extent;
    }
    return parseFloat(v) || 0;
  }

  Glass.prototype._setShapeUniforms = function (u, shapes) {
    var gl = this.gl;
    var n = shapes.length;
    var ctr = new Float32Array(MAX_SHAPES * 2);
    var siz = new Float32Array(MAX_SHAPES * 2);
    var rad = new Float32Array(MAX_SHAPES);
    var rnd = new Float32Array(MAX_SHAPES);
    for (var i = 0; i < n; i++) {
      ctr[i * 2] = shapes[i].cx; ctr[i * 2 + 1] = shapes[i].cy;
      siz[i * 2] = shapes[i].w;  siz[i * 2 + 1] = shapes[i].h;
      rad[i] = shapes[i].r;      rnd[i] = shapes[i].n;
    }
    gl.uniform1i(u('u_shapeCount'), n);
    gl.uniform2fv(u('u_shapeCenter'), ctr);
    gl.uniform2fv(u('u_shapeSize'), siz);
    gl.uniform1fv(u('u_shapeRadius'), rad);
    gl.uniform1fv(u('u_shapeRoundness'), rnd);
    gl.uniform1f(u('u_mergeRate'), this.o.mergeRate);
    gl.uniform2f(u('u_resolution'), this.w, this.h);
    gl.uniform2f(u('u_resolution1x'), this.cssW, this.cssH);
    gl.uniform1f(u('u_dpr'), this.dpr);
  };

  Glass.prototype._drawQuad = function (prog) {
    var gl = this.gl;
    var loc = gl.getAttribLocation(prog, 'a_position');
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  };

  Glass.prototype._renderFrame = function (shapes) {
    var gl = this.gl, o = this.o;

    // ── Pass 1: background + shadow ──
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fboBg.fb);
    gl.viewport(0, 0, this.w, this.h);
    gl.useProgram(this.progBg);
    var u = this.uBg;
    this._setShapeUniforms(u, shapes);
    gl.uniform1i(u('u_bgType'), this.source.ready ? this.source.bgType : 0);
    gl.uniform1f(u('u_bgTextureRatio'), this.source.ratio || 1);
    gl.uniform1i(u('u_bgTextureReady'), this.source.ready ? 1 : 0);
    gl.uniform1f(u('u_time'), this.time);
    gl.uniform1f(u('u_shadowExpand'), o.shadow.expand);
    gl.uniform1f(u('u_shadowFactor'), o.shadow.factor / 100);
    // Shadow offset is negated: shifting the sampled SDF left moves the
    // resulting shadow right.
    gl.uniform2f(u('u_shadowOffset'),
      -o.shadow.x * this.dpr, o.shadow.y * this.dpr);
    if (this.source.texture) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.source.texture);
      gl.uniform1i(u('u_bgTexture'), 0);
    }
    this._drawQuad(this.progBg);

    // ── Pass 2+3: separable blur at reduced resolution ──
    var k = this._kernel;
    var doBlur = o.blur.radius > 0;
    if (doBlur) {
      gl.useProgram(this.progBlur);
      var ub = this.uBlur;
      gl.uniform1i(ub('u_taps'), k.taps);
      gl.uniform1fv(ub('u_weights'), padTo(k.weights, MAX_BLUR_RADIUS + 1));
      gl.uniform1fv(ub('u_offsets'), padTo(k.offsets, MAX_BLUR_RADIUS + 1));
      gl.uniform1i(ub('u_tex'), 0);
      gl.activeTexture(gl.TEXTURE0);

      // Horizontal: full-res bg → reduced-res A (downsample happens here).
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.fboBlurA.fb);
      gl.viewport(0, 0, this.fboBlurA.w, this.fboBlurA.h);
      gl.bindTexture(gl.TEXTURE_2D, this.fboBg.tex);
      gl.uniform2f(ub('u_texelSize'), 1 / this.fboBlurA.w, 1 / this.fboBlurA.h);
      gl.uniform2f(ub('u_direction'), 1, 0);
      this._drawQuad(this.progBlur);

      // Vertical: A → B.
      gl.bindFramebuffer(gl.FRAMEBUFFER, this.fboBlurB.fb);
      gl.viewport(0, 0, this.fboBlurB.w, this.fboBlurB.h);
      gl.bindTexture(gl.TEXTURE_2D, this.fboBlurA.tex);
      gl.uniform2f(ub('u_direction'), 0, 1);
      this._drawQuad(this.progBlur);
    }

    // ── Pass 4: the glass ──
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.w, this.h);
    gl.useProgram(this.progMain);
    var um = this.uMain;
    this._setShapeUniforms(um, shapes);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.fboBg.tex);
    gl.uniform1i(um('u_bg'), 0);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, doBlur ? this.fboBlurB.tex : this.fboBg.tex);
    gl.uniform1i(um('u_blurredBg'), 1);

    gl.uniform1f(um('u_refThickness'), o.refraction.thickness);
    gl.uniform1f(um('u_refIor'), o.refraction.ior);
    gl.uniform1f(um('u_refDispersion'), o.refraction.dispersion);
    gl.uniform1f(um('u_fresnelRange'), o.fresnel.range);
    gl.uniform1f(um('u_fresnelHardness'), o.fresnel.hardness / 100);
    gl.uniform1f(um('u_fresnelFactor'), o.fresnel.factor / 100);
    gl.uniform1f(um('u_glareRange'), o.glare.range);
    gl.uniform1f(um('u_glareHardness'), o.glare.hardness / 100);
    gl.uniform1f(um('u_glareFactor'), o.glare.factor / 100);
    gl.uniform1f(um('u_glareConvergence'), o.glare.convergence / 100);
    gl.uniform1f(um('u_glareOppositeFactor'), o.glare.oppositeFactor / 100);
    gl.uniform1f(um('u_glareAngle'), o.glare.angle * Math.PI / 180);
    gl.uniform1i(um('u_blurEdge'), o.blur.edge && doBlur ? 1 : 0);
    gl.uniform4f(um('u_tint'),
      o.tint.r / 255, o.tint.g / 255, o.tint.b / 255, o.tint.a);
    this._drawQuad(this.progMain);

    // Release both sampler bindings. Left bound, fboBlurB would still be on
    // unit 1 when the next frame's blur pass renders *into* it — which the
    // driver reports as a framebuffer/texture feedback loop and skips the draw.
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, null);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, null);
  };

  function padTo(arr, n) {
    var out = new Float32Array(n);
    for (var i = 0; i < arr.length && i < n; i++) out[i] = arr[i];
    return out;
  }

  Glass.prototype._loop = function () {
    var self = this;
    var last = performance.now();

    function frame(now) {
      if (self._destroyed) return;
      self._raf = requestAnimationFrame(frame);
      var dt = Math.min((now - last) / 1000, 1 / 20);
      last = now;

      if (self._lost || !self._visible) return;

      // ── Render-on-demand ──
      // The reference runs an unconditional draw loop. Instead, redraw only
      // when something actually changed: a settling spring, an animated or
      // updated source, or an explicit invalidate(). A static scene costs
      // zero GPU.
      var sourceChanged = self.source.update();
      var springsMoving = false;

      for (var i = 0; i < self.o.shapes.length && i < MAX_SHAPES; i++) {
        var sp = self.springs[i];
        var px = sp.x.x, py = sp.y.x;
        sp.x.step(dt); sp.y.step(dt);
        // Finite-difference velocity in px/s, normalised — feeds squash/stretch.
        sp.vx = dt > 0 ? (sp.x.x - px) / dt / 1000 : 0;
        sp.vy = dt > 0 ? (sp.y.x - py) / dt / 1000 : 0;
        if (!sp.x.settled() || !sp.y.settled()) springsMoving = true;
      }

      if (self.source.animated) self.time += dt;

      if (!self._dirty && !sourceChanged && !springsMoving &&
          !self.source.animated) {
        return;
      }
      self._dirty = false;

      var shapes = self._resolveShapes();
      self._renderFrame(shapes);

      self._frames++;
      if (now - self._fpsT > 500) {
        self._fps = Math.round(self._frames * 1000 / (now - self._fpsT));
        self._frames = 0; self._fpsT = now;
      }
    }
    this._raf = requestAnimationFrame(frame);
  };

  /** Live-patch any option. Only reallocates when it must. */
  Glass.prototype.set = function (patch) {
    if (!patch) return this;
    var needsResize = patch.blur && patch.blur.quality !== undefined &&
      patch.blur.quality !== this.o.blur.quality;
    var newSource = patch.background !== undefined;
    var oldRadius = this.o.blur.radius;

    this.o = deepMerge(this.o, patch);

    if (this.o.blur.radius !== oldRadius) {
      this._kernel = gaussianKernel(this.o.blur.radius);
    }
    if (newSource && this.supported) {
      this.source.destroy();
      this.source = buildSource(this.o.background);
      this.source.attach(this.gl);
      var self = this;
      this.source.onready = function () { self.invalidate(); };
    }
    if (needsResize) { this.w = -1; this.resize(); }
    this.invalidate();
    return this;
  };

  Glass.prototype.get = function () { return deepMerge(this.o, null); };
  Glass.prototype.fps = function () { return this._fps; };

  /** Force a redraw right now, outside the rAF loop. */
  Glass.prototype.render = function () {
    if (!this.supported || this._lost) return;
    this._renderFrame(this._resolveShapes());
  };

  Glass.prototype.destroy = function () {
    this._destroyed = true;
    if (this._raf) cancelAnimationFrame(this._raf);
    var c = this.canvas;
    if (this._onPointer) {
      c.removeEventListener('pointermove', this._onPointer);
      c.removeEventListener('pointerleave', this._onLeave);
    }
    window.removeEventListener('resize', this._onResize);
    if (this._ro) this._ro.disconnect();
    if (this._io) this._io.disconnect();
    c.removeEventListener('webglcontextlost', this._onLost);
    c.removeEventListener('webglcontextrestored', this._onRestored);

    if (!this.supported) return;
    var gl = this.gl;
    this.source.destroy();
    freeFBO(gl, this.fboBg);
    freeFBO(gl, this.fboBlurA);
    freeFBO(gl, this.fboBlurB);
    gl.deleteBuffer(this.quad);
    gl.deleteProgram(this.progBg);
    gl.deleteProgram(this.progBlur);
    gl.deleteProgram(this.progMain);
  };

  // ═══════════════════════════════════════════════════════════════════════
  // Public API
  // ═══════════════════════════════════════════════════════════════════════
  return {
    DEFAULTS: DEFAULTS,
    create: function (canvas, options) { return new Glass(canvas, options); },
    isSupported: function () {
      try {
        var c = document.createElement('canvas');
        return !!c.getContext('webgl2');
      } catch (e) { return false; }
    },
    sources: {
      Image: ImageSource, Video: VideoSource,
      Canvas: CanvasSource, DOM: DOMSource, Procedural: ProceduralSource
    },
    _internal: {
      VERT: VERT, FRAG_BG: FRAG_BG, FRAG_BLUR: FRAG_BLUR, FRAG_MAIN: FRAG_MAIN,
      gaussianKernel: gaussianKernel, Spring: Spring, deepMerge: deepMerge,
      MAX_SHAPES: MAX_SHAPES, MAX_BLUR_RADIUS: MAX_BLUR_RADIUS,
      compile: compile, program: program, makeFBO: makeFBO, freeFBO: freeFBO,
      uniformCache: uniformCache
    }
  };
});
